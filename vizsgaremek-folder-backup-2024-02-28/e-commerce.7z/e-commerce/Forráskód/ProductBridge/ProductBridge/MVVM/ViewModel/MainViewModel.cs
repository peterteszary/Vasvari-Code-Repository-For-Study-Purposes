﻿namespace ProductBridge.ViewModel
{
    class MainViewModel
    {
    }
}
