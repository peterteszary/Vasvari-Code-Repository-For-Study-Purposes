## eCommerce Sync Theme

### First Update 2023-11-03

This is our WordPress theme, developed primarily by Péter Teszáry and Péter Bagi. We use Bootstrap as css framework and will use Sass later on. As part of the task allocation in the project, we will assign who will work on which part of the theme (php file).